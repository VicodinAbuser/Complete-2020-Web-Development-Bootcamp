﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'fi', {
	label: 'Tyyli',
	panelTitle: 'Muotoilujen tyylit',
	panelTitle1: 'Lohkojen tyylit',
	panelTitle2: 'Rivinsisäiset tyylit',
	panelTitle3: 'Objektien tyylit'
} );
